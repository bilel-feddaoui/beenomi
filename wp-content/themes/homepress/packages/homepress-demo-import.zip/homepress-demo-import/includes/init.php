<?php
\homepressDemoImport\classes\ThemeImport::init();
\homepressDemoImport\classes\PluginImport::init();