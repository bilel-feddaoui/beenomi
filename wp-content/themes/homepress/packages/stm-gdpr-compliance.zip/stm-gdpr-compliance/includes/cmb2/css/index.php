<?php
// Silence is golden
